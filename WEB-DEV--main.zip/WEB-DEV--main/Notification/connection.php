<?php
$host = "localhost";
$username = "root"; // default in XAMPP
$password = "";     // default in XAMPP
$dbname = "user_registration"; // your database name

$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
